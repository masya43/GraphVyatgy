﻿
class Program
{
    static void Main(string[] args)
    {
        int verticesCount = 6;
        List<Tuple<int, int>> edges = new List<Tuple<int, int>>
        {
            Tuple.Create(1, 4),//a
            Tuple.Create(1, 5),//b
            Tuple.Create(1, 6),//c
            Tuple.Create(2, 4),//d
            Tuple.Create(2, 5),//e
            Tuple.Create(2, 6),//f
            Tuple.Create(3, 4),//g
            Tuple.Create(3, 5),//h
            Tuple.Create(3, 6),//i
        };
        string[] edgeLabels = { "a", "b", "c", "d", "e", "f", "g", "h", "i" };

        Console.WriteLine("Свойства: Двудольный граф с вершинной раскраской ");

        // Вывод матрицы смежности
        Console.WriteLine("Матрица смежности:");
        PrintAdjacencyMatrix(verticesCount, edges);

        // Вывод матрицы инцидентности
        Console.WriteLine("Матрица инцидентности:");
        PrintIncidenceMatrix(verticesCount, edges, edgeLabels);
    }

    static void PrintAdjacencyMatrix(int verticesCount, List<Tuple<int, int>> edges)
    {
        int[,] adjacencyMatrix = new int[verticesCount + 1, verticesCount + 1];

        foreach (var edge in edges)
        {
            adjacencyMatrix[edge.Item1, edge.Item2] = 1;
            //Для неориентированного графа:
            adjacencyMatrix[edge.Item2, edge.Item1] = 1; 
        }

        // Вывод заголовка для вершин
        Console.Write("    ");
        for (int i = 1; i <= verticesCount; i++)
        {
            Console.Write($"{i} ");
        }
        Console.WriteLine();

        for (int i = 1; i <= verticesCount; i++)
        {
            Console.Write($"{i} | ");
            for (int j = 1; j <= verticesCount; j++)
            {
                Console.Write(adjacencyMatrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }

    static void PrintIncidenceMatrix(int verticesCount, List<Tuple<int, int>> edges, string[] edgeLabels)
    {
        int[,] incidenceMatrix = new int[verticesCount + 1, edges.Count];

        for (int j = 0; j < edges.Count; j++)
        {
            var edge = edges[j];
            incidenceMatrix[edge.Item1, j] = 1;
            // Для неориентированного графа:
            incidenceMatrix[edge.Item2, j] = 1;
        }
        // Вывод заголовка для рёбер
        Console.Write("     ");
        for (int j = 0; j < edges.Count; j++)
        {
            char label = (char)('a' + j);
            Console.Write($"{label}  ");
        }
        Console.WriteLine();

        for (int i = 1; i <= verticesCount; i++)
        {
            Console.Write($"{i} |");
            for (int j = 0; j < edges.Count; j++)
            {
                Console.Write(incidenceMatrix[i, j] >= 0 ? "  " : " ");
                Console.Write(incidenceMatrix[i, j]);
            }
            Console.WriteLine();
        }
    }
}