﻿
Console.WriteLine("Свойства: реберная взвешенность (с наличием отрицательных весов) с циклами");

// Вывод матрицы смежности
Console.WriteLine("Матрица смежности:");
PrintAdjacencyMatrix();

// Вывод матрицы инцидентности
Console.WriteLine("Матрица инцидентности:");
PrintIncidenceMatrix();
Console.WriteLine();

void PrintAdjacencyMatrix()
{
    Console.WriteLine(  "\r\n     1   2   3   4   5   6 " +
                        "\r\n 1 | 0   3   0   0   0   0 " +
                        "\r\n 2 | 0   0   7   0   0   0 " +
                        "\r\n 3 | 11  0   0   0   0   10" +
                        "\r\n 4 | 0   0   7   0   5   0 " +
                        "\r\n 5 | 0   0   0   0   0   0 " +
                        "\r\n 6 | 0   0   0   0   15  0 ");
}
void PrintIncidenceMatrix()
{
    Console.WriteLine(  "\r\n      a,  b,  c,  d,   e,   f,   g" +
                        "\r\n 1 |  3,  0,  0,  0,   0,   0, -11" +
                        "\r\n 2 | -3,  7,  0,  0,   0,   0,   0" +
                        "\r\n 3 |  0, -7, -7,  0,   0,  10,  11" +
                        "\r\n 4 |  0,  0,  7,  5,   0,   0,   0" +
                        "\r\n 5 |  0,  0,  0, -5, -15,   0,   0" +
                        "\r\n 6 |  0,  0,  0,  0,  15, -10,   0");
}